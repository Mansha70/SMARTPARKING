<?php
session_start();
include("connect.php");
 ?>
<!DOCTYPE html>
<html>

<head>
    <title>Page Title</title>
</head>

<body>
   <div style="text-align:center;padding:15%;">
    < style="font-size:50px;" font-weight:bold;">
    Hello<?php
    if(isset($session['email'])){
        $email=$_session['email'];
        $query=mysqli_query($conn,"SELECT users.* FROM users WHERE users.email='$email'")
        while($row=mysqli_fetch_array($query)){
            echo $row['firsname'].''.$row['email'];

        }
    }
    ?>
    </p>
    <a href="logout.php">logout</a>
    
   </div>
</body>

</html>
